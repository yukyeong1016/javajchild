import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.handler.MessageContext.Scope;

import oracle.sql.DATE;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Panel;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
public class NameSearchGUI {
	private JFrame frame;
	private JTextField year;
	private JTextField month;
	private JTextField day;
	private JTextField hour;
	private JTextField minutes;
	private JTable table;
	JScrollPane scrollPane;
	private JTextField hours;
	private JTextField minutess;
	String[] title = {"��ȭ��ȣ","�̸�","�ּ�","�ð�","���۽ð�","�����ð�"};
	Object[][] data;
	private JTextField namephone;
	String namephone1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NameSearchGUI window = new NameSearchGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NameSearchGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 848, 556);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	
	JLabel clientsearch = new JLabel("\uD68C\uC6D0\uC870\uD68C");
	clientsearch.setFont(new Font("����", Font.BOLD, 22));
	clientsearch.setHorizontalAlignment(SwingConstants.CENTER);
	clientsearch.setBounds(352, 10, 92, 48);
	frame.getContentPane().add(clientsearch);
	
	JButton closebutton = new JButton("\uB2EB\uAE30");
	closebutton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			frame.dispose();
		}
	});
	closebutton.setBounds(722, 479, 97, 23);
	frame.getContentPane().add(closebutton);
	
	JButton namesearch = new JButton("\uC774\uB984");
	namesearch.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			NameSearchGUI.main(null);
			frame.dispose();
		}
	});
	namesearch.setBounds(37, 43, 66, 23);
	frame.getContentPane().add(namesearch);
	
	JButton timesearch = new JButton("\uC2DC\uAC04");
	timesearch.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			ClientSearchGUI.main(null);
			frame.dispose();
		}
	});
	namephone = new JTextField();
	namephone.setBounds(631, 87, 66, 21);
	frame.getContentPane().add(namephone);
	namephone.setColumns(10);
	namephone.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 namephone1 = namephone.getText();
			 
		}});
	
	timesearch.setBounds(99, 43, 66, 23);
	frame.getContentPane().add(timesearch);
	
	JButton searchbutton1 = new JButton("\uAC80\uC0C9");
	searchbutton1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			NameSearchDAO dao = new NameSearchDAO();
			ArrayList<ClientSearchDTO> list1 = dao.NameSearch();
			if(list1.equals(namephone1)) {
				
			
			
			data = new Object[list1.size()][6];
			
			for(int i = 0; i < list1.size(); i++) {
				
				data[i][0] = list1.get(i).getPhonenumber();
				data[i][1] = list1.get(i).getName();
				data[i][2] = list1.get(i).getAddress();
				data[i][3] = list1.get(i).getPaytime();
				data[i][4] = list1.get(i).getStarttime();
				data[i][5] = list1.get(i).getEndtime();

			}
			
			
			
			
			
			
			table = new JTable(data, title);
			table.setVisible(true);
			scrollPane = new JScrollPane(table);
			scrollPane.setBounds(45, 131, 730, 280);
			scrollPane.setVisible(true);
			frame.getContentPane().add(scrollPane);
			
			
		}
		}	});
	searchbutton1.setBounds(709, 86, 66, 23);
	frame.getContentPane().add(searchbutton1);
	
	
}}
