package Pay;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Client.ClientVO;

public class PayDAO {
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
		
	
	public void connect() { //�����ϴ� ���� � �޼ҵ带 �̿��ϵ� �׻� �����ϴ� ��������.
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, user, password);
					
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if(rs!= null) rs.close();
			if(pst!= null) pst.close();
			if(conn!=null) conn.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public PayVO seatSelect(ClientVO vo, int seatnum) {
	connect();
	PayVO pVO = null;
	try{
		String sql = "insert into bookingroompay values(paynum.nextval, ?, ?, ?, null, null)";
		pst = conn.prepareStatement(sql);
		pst.setString(1, vo.getPhonenumber());
		pst.setInt(2, seatnum);
		pst.setInt(3, vo.getPaytime());
		pst.executeUpdate();
		
		pVO = new PayVO(vo.getPhonenumber(), seatnum, vo.getPaytime());
				
	}catch(Exception e) {
		e.printStackTrace();
	}finally {
		close();
	}
	return pVO;
		
		
		
		
	}

}
