package Pay;

public class PayVO {

	private String phonenumber;
	private int seatnumber;
	private int paytime;
	
	public PayVO(String phonenumber, int seatnumber, int paytime) {
		super();
		this.phonenumber = phonenumber;
		this.seatnumber = seatnumber;
		this.paytime = paytime;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public int getSeatnumber() {
		return seatnumber;
	}

	public int getPaytime() {
		return paytime;
	}

	public void setPaytime(int paytime) {
		this.paytime = paytime;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public void setSeatnumber(int seatnumber) {
		this.seatnumber = seatnumber;
	}
	
	
	
	
	
}

