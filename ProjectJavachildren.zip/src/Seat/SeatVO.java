package Seat;
import java.util.Date;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.GregorianCalendar;

import Pay.PayVO;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SeatVO {

	private int seatnumber;
	private int seatpartition;
	private long startdate;
	private long enddate;
	private String admin;
	private int livetableuse;
	
	
	public static void main(String[] args) {
		GregorianCalendar now = new GregorianCalendar();
		now.setTime(new Date());
		System.out.println(now.get(Calendar.HOUR)+1);
		SimpleDateFormat df = new SimpleDateFormat("yy-MM-DD hh:mm:ss");
		System.out.println(df.format(now.getTime()));
		Date today = new Date();
		System.out.println(today);
		System.out.println(df.format(today));
		java.util.Date utilDate = today;
		System.out.println(utilDate);
		
		
		
	}
	
	public SeatVO(int seatnumber, long l, long cnt) {
		super();
		this.seatnumber = seatnumber;
		this.startdate = l;
		this.enddate = cnt;
		
	}
	
	
	public SeatVO(int seatnumber, long startdate, int livetableuse) {
		super();
		this.seatnumber = seatnumber;
		this.startdate = startdate;
		this.livetableuse = livetableuse;
	}
	
	
	public SeatVO(int seatnumber, long startdate, long enddate, int livetableuse) {
		super();
		this.seatnumber = seatnumber;
		this.startdate = startdate;
		this.enddate = enddate;
		this.livetableuse = livetableuse;
	}

	public int getSeatnumber() {
		return seatnumber;
	}
	public void setSeatnumber(int seatnumber) {
		this.seatnumber = seatnumber;
	}
	public int getSeatpartition() {
		return seatpartition;
	}
	public void setSeatpartition(int seatpartition) {
		this.seatpartition = seatpartition;
	}
	public long getStartdate() {
		return startdate;
	}
	public void setStartdate(long startdate) {
		this.startdate = startdate;
	}
	public long getEnddate() {
		return enddate;
	}
	public void setEnddate(long enddate) {
		this.enddate = enddate;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	
	
	
	
	
	
	
	
	
	
}
