package Seat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import Client.ClientVO;
import Pay.PayVO;
import java.util.Date;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class SeatDAO {
	Connection conn = null;
	PreparedStatement pst = null;
	PreparedStatement pst1 = null;
	PreparedStatement pst2 = null;
	ResultSet rs = null;
	
	private Date now = null;
	private SimpleDateFormat df = null;
	
	
	public void connect() { //�����ϴ� ���� � �޼ҵ带 �̿��ϵ� �׻� �����ϴ� ��������.
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, user, password);
					
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if(rs!= null) rs.close();
			if(pst!= null) pst.close();
			if(conn!=null) conn.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public SeatVO enter(ClientVO vo, PayVO pVO) {
		connect();
		now = new Date();
		SeatVO sVO = null;
		int cnt = 1;
		
		try{
			
			String sql = "update bookingroomseat set starttime = ?, livetableuse = ? where seatnumber = ?";
			pst = conn.prepareStatement(sql);
			pst.setTimestamp(1, new java.sql.Timestamp(now.getTime()));
			pst.setInt(2, cnt);
			pst.setInt(3, pVO.getSeatnumber());
			pst.executeUpdate();
			
			
			String sql1 = "update bookingroomclient set liveuse = ?, starttime = ? where phonenumber = ?";
			pst1 = conn.prepareStatement(sql1);
			pst1.setInt(1, cnt);
			pst1.setTimestamp(2, new java.sql.Timestamp(now.getTime()));
			pst1.setString(3, pVO.getPhonenumber());
			pst1.executeUpdate();
			
			String sql2 = "update bookingroompay set starttime = ? where phonenumber = ?";
			pst2 = conn.prepareStatement(sql2);
			pst2.setTimestamp(1, new java.sql.Timestamp(now.getTime()));
			pst2.setString(2, pVO.getPhonenumber());
			pst2.executeUpdate();
									
			
			sVO = new SeatVO(pVO.getSeatnumber(), now.getTime(), cnt);
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return sVO;
			
					
		}

	public void out(ClientVO vo, PayVO pVO, SeatVO sVO) {
		connect();
		int cnt = 0;
		now = new Date();
		
		long end = now.getTime()-sVO.getStartdate();
		try{
			
			String sql = "update bookingroomseat set endtime = ?, livetableuse = ? where seatnumber = ?";
			pst = conn.prepareStatement(sql);
			pst.setTimestamp(1, new java.sql.Timestamp(end));
			pst.setInt(2, cnt);
			pst.setInt(3, sVO.getSeatnumber());
			pst.executeUpdate();
			
			
			String sql1 = "update bookingroomclient set liveuse = ?, endtime = ? where phonenumber = ?";
			pst1 = conn.prepareStatement(sql1);
			pst1.setInt(1, cnt);
			pst1.setTimestamp(2, new java.sql.Timestamp(end));
			pst1.setString(3, pVO.getPhonenumber());
			pst1.executeUpdate();
			
			sVO = new SeatVO(sVO.getSeatnumber(), sVO.getStartdate(), end, cnt);
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
			}
		
	}
	
	
	
	
	

