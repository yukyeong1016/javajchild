package ClientLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Client.ClientDAO;
import Client.ClientVO;
import �α���ȸ������_GUI.MainGUI;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JoinGUI {

	private JFrame frame;
	private JTextField tf_ClientName;
	private JTextField tf_ClientPhonenumber;
	private JTextField tf_ClientPassword;
	private JTextField tf_ClientPasswordCheck;
	private JTextField tf_ClientAddress;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JoinGUI window = new JoinGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JoinGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 404, 434);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel.setBounds(132, 24, 115, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("\uC774\uB984");
		label.setBounds(12, 82, 115, 34);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD654");
		label_1.setBounds(12, 126, 168, 40);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_2.setBounds(12, 176, 115, 34);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		label_3.setBounds(12, 220, 115, 40);
		frame.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("\uC8FC\uC18C(\uAD11\uC8FC \uB0A8\uAD6C)");
		label_4.setBounds(12, 270, 115, 21);
		frame.getContentPane().add(label_4);
		
		tf_ClientName = new JTextField();
		tf_ClientName.setBounds(183, 89, 168, 21);
		frame.getContentPane().add(tf_ClientName);
		tf_ClientName.setColumns(10);
		
		tf_ClientPhonenumber = new JTextField();
		tf_ClientPhonenumber.setColumns(10);
		tf_ClientPhonenumber.setBounds(183, 136, 168, 21);
		frame.getContentPane().add(tf_ClientPhonenumber);
		
		tf_ClientPassword = new JTextField();
		tf_ClientPassword.setColumns(10);
		tf_ClientPassword.setBounds(183, 183, 168, 21);
		frame.getContentPane().add(tf_ClientPassword);
		
		tf_ClientPasswordCheck = new JTextField();
		tf_ClientPasswordCheck.setColumns(10);
		tf_ClientPasswordCheck.setBounds(183, 230, 168, 21);
		frame.getContentPane().add(tf_ClientPasswordCheck);
		
		tf_ClientAddress = new JTextField();
		tf_ClientAddress.setColumns(10);
		tf_ClientAddress.setBounds(183, 270, 168, 21);
		frame.getContentPane().add(tf_ClientAddress);
		
		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = tf_ClientName.getText(); //�Է��� ���� ������ ��ƾ� �ڴ�~
				String ph = tf_ClientPhonenumber.getText();
				String pw = tf_ClientPassword.getText();
				String pwcheck = tf_ClientPasswordCheck.getText();
				String ad = tf_ClientAddress.getText();
				
				
				if(pw.equals(pwcheck)) {
				ClientVO vo = new ClientVO(ph, pw, name, ad);
				ClientDAO dao = new ClientDAO();
				int cnt = dao.joinInsert(vo);
					if(cnt==1) 
						JOptionPane.showMessageDialog(null, "ȸ������  ����");
						
				}else{
					JOptionPane.showMessageDialog(null, "��й�ȣ�� ��ġ���� �ʽ��ϴ�.","ȸ������", JOptionPane.ERROR_MESSAGE);
					tf_ClientPassword.setText("");
					tf_ClientPasswordCheck.setText("");
				}
				frame.dispose();
				MainGUI.main(null);
			}
		});
		btnNewButton.setBounds(77, 337, 115, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				MainGUI.main(null);
			}
		});
		btnNewButton_1.setBounds(217, 337, 108, 23);
		frame.getContentPane().add(btnNewButton_1);
	}
}
