package ClientLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import Client.ClientDAO;
import Client.ClientVO;
import ClientView.FirstVIewGUI;
import �α���ȸ������_GUI.MemberVO;
import �α���ȸ������_GUI.memberDAO;

import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginGUI {

	private JFrame frame;
	private JTextField tf_LoginPN;
	private JTextField tf_LoginPW;

	/**
	 * Launch the application.
	 */

	

	/**
	 * Create the application.
	 */
	public LoginGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 354);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uB85C\uADF8\uC778");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(152, 29, 124, 42);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("\uD734\uB300\uC804\uD654 \uBC88\uD638");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(37, 81, 124, 42);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(37, 133, 124, 42);
		frame.getContentPane().add(label_1);
		
		tf_LoginPN = new JTextField();
		tf_LoginPN.setBounds(206, 92, 169, 21);
		frame.getContentPane().add(tf_LoginPN);
		tf_LoginPN.setColumns(10);
		
		tf_LoginPW = new JTextField();
		tf_LoginPW.setBounds(206, 144, 169, 21);
		frame.getContentPane().add(tf_LoginPW);
		tf_LoginPW.setColumns(10);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\uC790\uB3D9 \uB85C\uADF8\uC778 \uC120\uD0DD");
		rdbtnNewRadioButton.setBounds(143, 189, 165, 23);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		JButton btn_Login = new JButton("\uB85C\uADF8\uC778");
		btn_Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = tf_LoginPN.getText(); //�Է��� ���� ������ ��ƾ� �ڴ�~
				String pw = tf_LoginPW.getText();
				
				ClientVO vo = new ClientVO(id, pw);
				ClientDAO dao = new ClientDAO();
				boolean success = dao.loginSelect(vo);
				
				if (success==true) {
					FirstVIewGUI view = new FirstVIewGUI(vo, null, null);
					frame.dispose();
				}else {
					JOptionPane.showMessageDialog(null, "ID�� PW�� ���� �ʽ��ϴ�.", "�α���", JOptionPane.ERROR_MESSAGE);
				}
			
			}
		});
		btn_Login.setBounds(98, 247, 97, 23);
		frame.getContentPane().add(btn_Login);
		
		JButton btn_Join = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btn_Join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				JoinGUI join = new JoinGUI();
				
				
			}
		});
		btn_Join.setBounds(223, 247, 97, 23);
		frame.getContentPane().add(btn_Join);
	}
}
