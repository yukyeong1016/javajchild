package ClientView;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import Client.ClientDAO;
import Client.ClientVO;
import ClientLogin.LoginGUI;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TimePayGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public TimePayGUI(ClientVO vo) {
		initialize(vo);
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(ClientVO vo) {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC774\uC6A9 \uC2DC\uAC04 \uC120\uD0DD");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(148, 10, 141, 59);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("4\uC2DC\uAC04");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "4�ð� ���� �����Ͻðڽ��ϱ�?");
				ClientDAO dao = new ClientDAO();
				ClientVO votime = dao.Timepay(vo);
				
				if (votime!=null) {
					JOptionPane.showMessageDialog(null, "������ �Ϸ�Ǿ����ϴ�.");
					frame.dispose();
					FirstVIewGUI view = new FirstVIewGUI(votime, null, null);
				}
				
			}
		});
		btnNewButton.setBounds(68, 79, 125, 59);
		frame.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("8\uC2DC\uAC04");
		button.setBounds(224, 79, 125, 59);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("\uC77C\uAD8C\r\n(24\uC2DC\uAC04)");
		button_1.setBounds(68, 160, 125, 59);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("\uC8FC\uAC04\uAD8C\r\n(168\uC2DC\uAC04)");
		button_2.setBounds(224, 160, 125, 59);
		frame.getContentPane().add(button_2);
	}

}
