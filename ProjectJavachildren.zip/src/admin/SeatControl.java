package admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.CardLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SeatControl {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeatControl window = new SeatControl();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SeatControl() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC88C\uC11D\uC870\uC815 \uD398\uC774\uC9C0\uC785\uB2C8\uB2E4.");
		lblNewLabel.setBounds(53, 57, 281, 118);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\uB4A4\uB85C \uAC00\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			BookingRoomClient_seat manage = new BookingRoomClient_seat();
			frame.dispose();
			
			
			}
		});
		btnNewButton.setBounds(248, 197, 97, 23);
		frame.getContentPane().add(btnNewButton);
		
	
	}

}
