package admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminGUI window = new AdminGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 329, 334);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn_clientSearch = new JButton("\uD68C\uC6D0\uC870\uD68C");
		btn_clientSearch.setBounds(12, 76, 137, 80);
		frame.getContentPane().add(btn_clientSearch);
		
		JButton btn_seatSearch = new JButton("\uC88C\uC11D\uC870\uD68C");
		btn_seatSearch.setBounds(164, 76, 137, 80);
		frame.getContentPane().add(btn_seatSearch);
		
		JButton btn_clientManage = new JButton("\uD68C\uC6D0\uAD00\uB9AC");
		btn_clientManage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			AdminClientManageGUI manage = new AdminClientManageGUI();
			frame.dispose();
			
			}
		});
		btn_clientManage.setBounds(12, 205, 137, 80);
		frame.getContentPane().add(btn_clientManage);
		
		JButton btn_seatManage = new JButton("\uC88C\uC11D\uAD00\uB9AC");
		btn_seatManage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookingRoomClient_seat manageSeat = new BookingRoomClient_seat();
				frame.dispose();
			}
		});
		btn_seatManage.setBounds(164, 205, 137, 80);
		frame.getContentPane().add(btn_seatManage);
		
		JLabel lblNewLabel = new JLabel("\uAD00\uB9AC\uC790 \uBAA8\uB4DC");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(85, 10, 137, 44);
		frame.getContentPane().add(lblNewLabel);
	}
}
