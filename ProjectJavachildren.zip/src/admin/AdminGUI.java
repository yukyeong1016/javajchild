package admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 * @param vo 
	 */
	public AdminGUI(AdminVO vo) {
		initialize(vo);
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 * @param vo 
	 */
	private void initialize(AdminVO vo) {
		frame = new JFrame();
		frame.setBounds(100, 100, 329, 239);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn_clientSearch = new JButton("\uD68C\uC6D0\uC870\uD68C");
		btn_clientSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SearchMenu menu = new SearchMenu();
				frame.dispose();
								
			}
		});
		btn_clientSearch.setBounds(12, 76, 137, 80);
		frame.getContentPane().add(btn_clientSearch);
		
		JButton btn_seatSearch = new JButton("\uC88C\uC11D\uC870\uD68C");
		btn_seatSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ClientSeat seat = new ClientSeat();
				frame.dispose();
			}
		});
		btn_seatSearch.setBounds(164, 76, 137, 80);
		frame.getContentPane().add(btn_seatSearch);
		
		JLabel lblNewLabel = new JLabel("\uAD00\uB9AC\uC790 \uBAA8\uB4DC");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(85, 10, 137, 44);
		frame.getContentPane().add(lblNewLabel);
	}
}
