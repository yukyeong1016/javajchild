package admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;

public class AdminClientManageGUI {

	private JFrame frame;
	private JTable clientTable;
	
	String[] columnsName = {"�̸�", "��ȭ��ȣ", "�ּ�"};
	String[][] data = {
			{"������", "010-5096-7148", "���� ������"},
			{"������", "010-1111-1111", "�ϱ�"}	};

	
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminClientManageGUI window = new AdminClientManageGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminClientManageGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 748, 433);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		clientTable = new JTable(2, 3);
		clientTable.setBounds(0, 0, 732, 394);
		frame.getContentPane().add(clientTable);
	}
}
