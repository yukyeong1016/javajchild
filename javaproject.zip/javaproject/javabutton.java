package javaproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.SpringLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class javabutton {

	private JFrame frame;
	private JLabel lblNewLabel_0;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					javabutton window = new javabutton();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public javabutton() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(40, 27, 129, 89);
		frame.getContentPane().add(panel);
		
		lblNewLabel_0 = new JLabel("New label");
		panel.add(lblNewLabel_0);
		
		JButton btnNewButton = new JButton("New button");
		panel.add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(261, 27, 129, 89);
		frame.getContentPane().add(panel_1);
		
		lblNewLabel_3 = new JLabel("New label");
		panel_1.add(lblNewLabel_3);
		
		JButton btnNewButton_1 = new JButton("New button");
		panel_1.add(btnNewButton_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(40, 126, 129, 100);
		frame.getContentPane().add(panel_2);
		
		JButton btnNewButton_2 = new JButton("New button");
		panel_2.add(btnNewButton_2);
		
		lblNewLabel_1 = new JLabel("New label");
		panel_2.add(lblNewLabel_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(271, 126, 123, 100);
		frame.getContentPane().add(panel_3);
		
		lblNewLabel_2 = new JLabel("New label");
		panel_3.add(lblNewLabel_2);
		
		JButton btnNewButton_3 = new JButton("New button");
		panel_3.add(btnNewButton_3);
		
		JButton btn_change = new JButton("\uBCC0\uACBD");
		btn_change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i = 0; i<4; i++) {				
//				lblNewLabel_i.setText("���x");
				}
			}
		});
		btn_change.setBounds(173, 228, 97, 23);
		frame.getContentPane().add(btn_change);
		
		
		
		
	}
}
