package javaproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Test {

	private JFrame frame;
	private JLabel lb;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test window = new Test();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Test() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);

		lb = new JLabel("0");
		springLayout.putConstraint(SpringLayout.NORTH, lb, 82, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, lb, 158, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, lb, -95, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, lb, -162, SpringLayout.EAST, frame.getContentPane());
		lb.setFont(new Font("Arial Narrow", Font.PLAIN, 33));
		lb.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lb);

		TimeThread_6 my = new TimeThread_6();
		my.start();

	}

	public class TimeThread_4 extends Thread {

		@Override
		public void run() {// 4�ð� -> 14400��
			int cnt = 14400;

			// 4�ð� �ú���
			// �� (4*3600)/3600
			// �� (4*3600)%3600/60
			// �� (4*3600)%3600%60��
			while (true) {
				int hour = cnt / 3600;
				int minute = cnt % 3600 / 60;
				int second = cnt % 3600 % 60;

				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}
			}
		}
	}

	public class TimeThread_6 extends Thread {
		public void run() {
			int cnt = 21600;

			while (true) {
				int hour = cnt / 3600;
				int minute = cnt % 3600 / 60;
				int second = cnt % 3600 % 60;

				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}
			}
		}
	}

	public class TimeThread_24 extends Thread {
		public void run() {
			int cnt = 86400;

			while (true) {
				int hour = cnt / 3600;
				int minute = cnt % 3600 / 60;
				int second = cnt % 3600 % 60;

				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}
			}

		}
	}

	public class TimeThread_168 extends Thread {
		public void run() {
			int cnt = 604800;

			while (true) {
				int hour = cnt / 3600;
				int minute = cnt % 3600 / 60;
				int second = cnt % 3600 % 60;

				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}

			}
		}
	}
}
