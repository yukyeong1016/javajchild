package javaproject;

public class TimerModel {

}
