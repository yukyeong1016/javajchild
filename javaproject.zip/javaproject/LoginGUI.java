package javaproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginGUI {

	private JFrame frame;
	private JTextField tf_loginid;
	private JTextField tf_loginpw;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public LoginGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uB85C\uADF8\uC778");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("HY����L", Font.PLAIN, 30));
		lblNewLabel.setBounds(126, 31, 176, 54);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("HY����L", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(80, 95, 77, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("HY����L", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(80, 154, 77, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btn_login = new JButton("\uD655\uC778");
		btn_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String phonenumber = tf_loginid.getText();
				String pw = tf_loginpw.getText();

				ClientDAO dao = new ClientDAO();
				ClientVO vo = dao.loginSelect(phonenumber, pw);

				if (vo == null) {
					JOptionPane.showMessageDialog(null, "�α��� ����", "�α���", JOptionPane.ERROR_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, vo.getName()+"�� ȯ���մϴ�.");
				}
				
			}
		});
		btn_login.setFont(new Font("HY����L", Font.PLAIN, 23));
		btn_login.setBounds(167, 207, 100, 44);
		frame.getContentPane().add(btn_login);
		
		tf_loginid = new JTextField();
		tf_loginid.setBounds(186, 92, 116, 21);
		frame.getContentPane().add(tf_loginid);
		tf_loginid.setColumns(10);
		
		tf_loginpw = new JTextField();
		tf_loginpw.setBounds(186, 151, 116, 21);
		frame.getContentPane().add(tf_loginpw);
		tf_loginpw.setColumns(10);
	}
}
