package javaproject;

public class BookinRoomClient_seatVO {
	
	private String phonenumber = null;
	private String pw = null;
	private String name = null;
	private String address = null;
	
	public BookinRoomClient_seatVO(String phonenumber, String pw, String name, String address) {
		super();
		this.phonenumber = phonenumber;
		this.pw = pw;
		this.name = name;
		this.address = address;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public String getPw() {
		return pw;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}
	
	

}
