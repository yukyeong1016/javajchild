package javaproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BookingRoomClient_seatDAO {
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	public void connect() { // �����ε� �ϰ� �����ͺ��̽� ���ᰴü ������ �����ϰ� ���ǹǷ� �޼ҵ�� ����
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";

			conn = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() { // �������� �Ųٷ� �ݾ������.
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public BookinRoomClient_seatVO bookingRoomClient_out(String phonenumber, String password) {
		
		connect();
		
		BookinRoomClient_seatVO brc_vo = null;
		
		String sql = "select * from bookingroomclient where phonenumber = ? and password = ?";
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setNString(1, phonenumber);
			pst.setNString(2, password);
			
			rs = pst.executeQuery(); // select�Ҷ��� Query
			
			while(rs.next()) {
				String getPhonenumber = rs.getString(1); 
				String getPw = rs.getString(2);
				String getName = rs.getString(3);
				String getAddress = rs.getString(4);
				
				brc_vo = new BookinRoomClient_seatVO(getPhonenumber, getPw, getName, getAddress);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return brc_vo;
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
