package javaproject;

public class ClientVO {
	private String phonenumber;
	private String pw;
	private String name;
	private String address;
	
	public ClientVO(String phonenumber, String pw, String name, String address) {
		super();
		this.phonenumber = phonenumber;
		this.pw = pw;
		this.name = name;
		this.address = address;
	}
	

	public String getPhonenumber() {
		return phonenumber;
	}

	public String getPw() {
		return pw;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}
	

}
