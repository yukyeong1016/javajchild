package javaproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class BookingRoomClient_out {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookingRoomClient_out window = new BookingRoomClient_out();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public BookingRoomClient_out() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setTitle("�Խ�, ���");
		frame.setBounds(100, 100, 453, 301);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn_out = new JButton("\uD1F4\uC2E4");
		btn_out.setForeground(new Color(0, 0, 0));
		btn_out.setFont(new Font("HY����L", Font.PLAIN, 25));
		btn_out.setBackground(new Color(255, 215, 0));
		btn_out.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�.");
//					�������� ���ư���
//					frame.dispose();
			}
		});
		btn_out.setBounds(262, 73, 97, 85);
		frame.getContentPane().add(btn_out);
		
		JButton btn_in = new JButton("\uC785\uC2E4");
		btn_in.setForeground(new Color(0, 0, 0));
		btn_in.setFont(new Font("HY����L", Font.PLAIN, 25));
		btn_in.setBackground(new Color(255, 215, 0));
		btn_in.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookingRoomClient_seat seat = new BookingRoomClient_seat();
				frame.dispose();
			}
		});
		btn_in.setBounds(85, 73, 97, 85);
		frame.getContentPane().add(btn_in);
	}

}
