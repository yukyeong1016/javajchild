package javaproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class BookingRoomClient_tm {

	private JFrame frame;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public BookingRoomClient_tm() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn_time = new JButton("\uC774\uC6A9\uC2DC\uAC04");
		btn_time.setBackground(new Color(255, 69, 0));
		btn_time.setBounds(81, 77, 97, 99);
		frame.getContentPane().add(btn_time);
		
		JButton btn_move = new JButton("\uC790\uB9AC\uC774\uB3D9");
		btn_move.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookingRoomClient_seat seat = new BookingRoomClient_seat();
				frame.dispose();
			}
		});
		btn_move.setBounds(249, 77, 97, 99);
		frame.getContentPane().add(btn_move);
	}

}
