package javaproject;

import java.awt.EventQueue;
import java.awt.TextField;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Timer {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Timer window = new Timer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Timer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public class GUI implements ItemListener,WindowListener,TextListener{
		private TextField hour = new TextField("hour",2);
		private TextField minute = new TextField("min",2);
		private TextField second = new TextField("sec",2);
		private TextField hour1 = new TextField(3);
		private TextField minute1 = new TextField(3);
		private TextField second1 = new TextField(3);
		private TextField hour2 = new TextField(3);
		private TextField minute2 = new TextField(3);
		private TextField second2 = new TextField(3);
		@Override
		public void textValueChanged(TextEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowClosed(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowClosing(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void itemStateChanged(ItemEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
class DownCounter implements Runnable{
	private int hour=0;
	private int minute=0;
	private int second=0;
	
	private long finalTime;
	private TextField hour1;
	
	public DownCounter(int hour, int minute, int second){
		finalTime = System.currentTimeMillis() + hour*3600*1000 + minute*60*1000+second*1000;
		
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	
	int hour(long millisec) {
		return(int)((millisec/(360000))%24)+9;
	}
	int minute(long millisec) {
		return(int)((millisec/6000)%60);
	}
	int second(long millisec) {
		return(int)((millisec/1000)%60);
	}
	public void run() {
		
		long startTime = 0;
		while(startTime <= finalTime) {
			startTime = System.currentTimeMillis();
			hour1.setText(String.valueOf(hour));
			TextField minute1 = null;
			minute1.setText(String.valueOf(minute));
			TextField second1 = null;
			second1.setText(String.valueOf(second));
			
			long dt = finalTime - startTime;
			TextField hour2 = null;
			hour2.setText(String.valueOf(hour(dt)-9));
			TextField minute2 = null;
			minute2.setText(String.valueOf(minute((dt))));
			TextField second2 = null;
			second2.setText(String.valueOf(second(dt)));
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
}
}
