package javaproject;

public class Time {
	
	private int cnt=0;
	private int hour = cnt/3600;
	private int minute = cnt % 3600 / 60;
	private int second = cnt % 3600 % 60;
	
	public Time(int cnt, int hour, int minute, int second) {
		super();
		this.cnt = cnt;
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}

	public class TimeThread_4 extends Thread {

		@Override
		public void run() {// 4�ð� -> 14400��
			int cnt = 14400;

			// 4�ð� �ú���
			// �� (4*3600)/3600
			// �� (4*3600)%3600/60
			// �� (4*3600)%3600%60��
			while (true) {
//				int hour = cnt / 3600;
//				int minute = cnt % 3600 / 60;
//				int second = cnt % 3600 % 60;

	//			lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}
			}
		}
	}

	public class TimeThread_6 extends Thread {
		public void run() {
			int cnt = 21600;

			while (true) {
//				int hour = cnt / 3600;
//				int minute = cnt % 3600 / 60;
//				int second = cnt % 3600 % 60;

//				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}
			}
		}
	}

	public class TimeThread_24 extends Thread {
		public void run() {
			int cnt = 86400;

			while (true) {
//				int hour = cnt / 3600;
//				int minute = cnt % 3600 / 60;
//				int second = cnt % 3600 % 60;

//				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}
			}

		}
	}

	public class TimeThread_168 extends Thread {
		public void run() {
			int cnt = 604800;

			while (true) {
//				int hour = cnt / 3600;
//				int minute = cnt % 3600 / 60;
//				int second = cnt % 3600 % 60;

//				lb.setText(hour + ":" + minute + ":" + second);
				cnt--;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (cnt < 0) {
					break;
				}

			}
		}
	}

}
