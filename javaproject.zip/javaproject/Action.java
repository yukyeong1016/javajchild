package javaproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Action {
	public static void main(String[] args) {
		Frame f = new Frame();
	}
}

class Frame extends JFrame{
	private JButton button;
	private JPanel panel;
	private JLabel label;
	private Listener listener = new Listener();
	
	public Frame() {
		this.setTitle("�̺�Ʈ");
		this.setSize(300, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		label = new JLabel("��");
		button = new JButton("��ư");
		
		button.addActionListener(listener);
		panel.add(button);
		panel.add(label);
		
		this.add(panel);
		this.setVisible(true);
	}
	class Listener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == button) {
				if(button.getText().equals("��ư"))
					button.setText("��ư1����");
				else if(button.getText().equals("��ư1����"))
					button.setText("��ư");
			}
		}
	}
}