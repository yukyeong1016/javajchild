
public class ClientSearchDTO {
	private String phonenumber;
	private String password;
	private String name;
	private String address;
	private int paytime;
	private String starttime;
	private String endtime;
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPaytime() {
		return paytime;
	}
	public void setPaytime(int paytime) {
		this.paytime = paytime;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public ClientSearchDTO(String phonenumber, String password, String name, String address, int paytime,
			String starttime, String endtime) {
		super();
		this.phonenumber = phonenumber;
		this.password = password;
		this.name = name;
		this.address = address;
		this.paytime = paytime;
		this.starttime = starttime;
		this.endtime = endtime;
	}
	
	
}
