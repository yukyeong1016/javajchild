import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.handler.MessageContext.Scope;

import oracle.sql.DATE;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Panel;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
public class ClientSearchGUI {

	private JFrame frame;
	private JTextField year;
	private JTextField month;
	private JTextField day;
	private JTextField hour;
	private JTextField minutes;
	private JTable table;
	JScrollPane scrollPane;
	private JTextField hours;
	private JTextField minutess;

	
	String[] title = {"��ȭ��ȣ","�̸�","�ּ�","�ð�","���۽ð�","�����ð�"};
	Object[][] data;
	private JTable table_1;
	Scanner sc = new Scanner(System.in);
	private JTextField seconds;
	private JTextField secondss;
	
	String year1;
	String month1;
	String day1;
	String hour1;
	String minutes1;
	String seconds1;
	String hours1;
	String minutess1;
	String secondss1;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientSearchGUI window = new ClientSearchGUI();
					window.frame.setVisible(true);
					
		
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClientSearchGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 847, 551);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0\uC870\uD68C");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 22));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(352, 10, 92, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\uB2EB\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
			}
		});
		btnNewButton.setBounds(722, 479, 97, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("\uB144\uB3C4");
		lblNewLabel_1.setBounds(123, 76, 34, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uC6D4");
		lblNewLabel_2.setBounds(193, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("\uC77C");
		lblNewLabel_2_1.setBounds(251, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_3 = new JLabel("\uC2DC");
		lblNewLabel_2_3.setBounds(309, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel("\uBD84");
		lblNewLabel_2_4.setBounds(373, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_4);
		
		
		
		
		year = new JTextField();
		year.setBounds(34, 73, 83, 21);
		frame.getContentPane().add(year);
		year.setColumns(10);
		year.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 year1 = year.getText();
				
			}
		});


		month = new JTextField();
		month.setColumns(10);
		month.setBounds(154, 73, 34, 21);
		frame.getContentPane().add(month);
		month.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				month1 = month.getText();
				
			}
		});
		
		day = new JTextField();
		day.setColumns(10);
		day.setBounds(214, 73, 34, 21);
		frame.getContentPane().add(day);
		day.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				day1 = day.getText();
				
			}
		});
		
		hour = new JTextField();
		hour.setBounds(265, 73, 41, 21);
		frame.getContentPane().add(hour);
		hour.setColumns(10);
		hour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 hour1 = hour.getText();
				
			}
		});
		
		minutes = new JTextField();
		minutes.setBounds(329, 73, 41, 21);
		frame.getContentPane().add(minutes);
		minutes.setColumns(10);
		minutes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				minutes1 = minutes.getText();
				
			}
		});
		
		
		
		JLabel lblNewLabel_3 = new JLabel("~");
		lblNewLabel_3.setBounds(468, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		hours = new JTextField();
		hours.setColumns(10);
		hours.setBounds(494, 73, 41, 21);
		frame.getContentPane().add(hours);
		hours.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hours1 = hours.getText();
				
			}
		});
		
		JLabel lblNewLabel_2_3_1 = new JLabel("\uC2DC");
		lblNewLabel_2_3_1.setBounds(538, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_3_1);
		
		minutess = new JTextField();
		minutess.setColumns(10);
		minutess.setBounds(559, 73, 41, 21);
		frame.getContentPane().add(minutess);
		minutess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				minutess1 = minutess.getText();
				
			}
		});
		
		frame.setVisible(true);
		
		JLabel lblNewLabel_2_4_1 = new JLabel("\uBD84");
		lblNewLabel_2_4_1.setBounds(605, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_4_1);
		
		
		JButton btnNewButton_1 = new JButton("\uAC80\uC0C9");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClientSearchDAO dao = new ClientSearchDAO();
				ArrayList<ClientSearchDTO> list = dao.allSearch();
				ArrayList<String> list1 = new ArrayList<String>();
				
				
				// 1. �˻���ư �������� �Է��� ���� �����ͼ� ���ο� �������� ����
				
				// 2. ��¥(0109), 9, 12 -> DB select
				//select ? from ���̺� �� (where -> 0109, 9<= , 12>=)
				// ������ �� ������ ���ο� ������ ����
				
				// 3. DB�� ���� ������ ������ ������ �ǳ� ���� �ʿ�!
				// �ǳڿ� �߰��ؼ� ����ֱ� -> get/������
				
				
				
				data = new Object[list.size()][6];
				
				for(int i = 0; i < list.size(); i++) {
					
					data[i][0] = list.get(i).getPhonenumber();
					data[i][1] = list.get(i).getName();
					data[i][2] = list.get(i).getAddress();
					data[i][3] = list.get(i).getPaytime();
					data[i][4] = list.get(i).getStarttime();
					data[i][5] = list.get(i).getEndtime();

				}
				
				
				
				
				
				
				table = new JTable(data, title);
				table.setVisible(true);
				scrollPane = new JScrollPane(table);
				scrollPane.setBounds(45, 131, 730, 280);
				scrollPane.setVisible(true);
				frame.getContentPane().add(scrollPane);
				
				
			}
		});
		btnNewButton_1.setBounds(699, 72, 66, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		seconds = new JTextField();
		seconds.setColumns(10);
		seconds.setBounds(403, 73, 41, 21);
		frame.getContentPane().add(seconds);
		seconds.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 seconds1 = seconds.getText();
				
			}
		});
		
		JLabel lblNewLabel_2_5 = new JLabel("\uCD08");
		lblNewLabel_2_5.setBounds(448, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_5);
		
		secondss = new JTextField();
		secondss.setColumns(10);
		secondss.setBounds(626, 73, 41, 21);
		frame.getContentPane().add(secondss);
		secondss.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				secondss1 = secondss.getText();
				
			}
		});
		
		JLabel lblNewLabel_2_4_2 = new JLabel("\uCD08");
		lblNewLabel_2_4_2.setBounds(671, 76, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_4_2);
		

		System.out.println(year1 + month1 + day1 + hour1 + minutes1 + seconds1);
	}
	}

