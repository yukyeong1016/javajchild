package ClientLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Client.ClientDAO;
import Client.ClientVO;
import �α���ȸ������_GUI.MainGUI;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class JoinGUI {

	private JFrame frame;
	private JTextField tf_ClientName;
	private JTextField tf_ClientPhonenumber;
	private JTextField tf_ClientPassword;
	private JTextField tf_ClientPasswordCheck;
	private JTextField tf_ClientAddress;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JoinGUI window = new JoinGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JoinGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBounds(100, 100, 404, 434);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel.setFont(new Font("HY����L", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(132, 24, 115, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("\uC774\uB984");
		label.setFont(new Font("HY����L", Font.PLAIN, 12));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(57, 82, 86, 34);
		frame.getContentPane().add(label);
		
		JLabel lblgh = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD638");
		lblgh.setFont(new Font("HY����L", Font.PLAIN, 12));
		lblgh.setHorizontalAlignment(SwingConstants.CENTER);
		lblgh.setBounds(36, 126, 86, 40);
		frame.getContentPane().add(lblgh);
		
		JLabel label_2 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_2.setFont(new Font("HY����L", Font.PLAIN, 12));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setBounds(46, 176, 86, 34);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		label_3.setFont(new Font("HY����L", Font.PLAIN, 12));
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setBounds(31, 220, 86, 40);
		frame.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("\uC8FC\uC18C");
		label_4.setFont(new Font("HY����L", Font.PLAIN, 12));
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setBounds(57, 270, 86, 21);
		frame.getContentPane().add(label_4);
		
		tf_ClientName = new JTextField();
		tf_ClientName.setBounds(134, 89, 168, 21);
		frame.getContentPane().add(tf_ClientName);
		tf_ClientName.setColumns(10);
		
		tf_ClientPhonenumber = new JTextField();
		tf_ClientPhonenumber.setColumns(10);
		tf_ClientPhonenumber.setBounds(134, 136, 168, 21);
		frame.getContentPane().add(tf_ClientPhonenumber);
		
		tf_ClientPassword = new JTextField();
		tf_ClientPassword.setColumns(10);
		tf_ClientPassword.setBounds(134, 183, 168, 21);
		frame.getContentPane().add(tf_ClientPassword);
		
		tf_ClientPasswordCheck = new JTextField();
		tf_ClientPasswordCheck.setColumns(10);
		tf_ClientPasswordCheck.setBounds(134, 230, 168, 21);
		frame.getContentPane().add(tf_ClientPasswordCheck);
		
		tf_ClientAddress = new JTextField();
		tf_ClientAddress.setColumns(10);
		tf_ClientAddress.setBounds(134, 270, 168, 21);
		frame.getContentPane().add(tf_ClientAddress);
		
		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.setFont(new Font("HY����L", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = tf_ClientName.getText(); //�Է��� ���� ������ ��ƾ� �ڴ�~
				String ph = tf_ClientPhonenumber.getText();
				String pw = tf_ClientPassword.getText();
				String pwcheck = tf_ClientPasswordCheck.getText();
				String ad = tf_ClientAddress.getText();
				
				
				if(pw.equals(pwcheck)) {
				ClientVO vo = new ClientVO(ph, pw, name, ad);
				ClientDAO dao = new ClientDAO();
				int cnt = dao.joinInsert(vo);
					if(cnt==1) 
						JOptionPane.showMessageDialog(null, "ȸ������  ����");
						
				}else{
					JOptionPane.showMessageDialog(null, "��й�ȣ�� ��ġ���� �ʽ��ϴ�.","ȸ������", JOptionPane.ERROR_MESSAGE);
					tf_ClientPassword.setText("");
					tf_ClientPasswordCheck.setText("");
				}
				frame.dispose();
				MainGUI.main(null);
			}
		});
		btnNewButton.setBounds(57, 337, 115, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.setFont(new Font("HY����L", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				MainGUI.main(null);
			}
		});
		btnNewButton_1.setBounds(200, 337, 108, 23);
		frame.getContentPane().add(btnNewButton_1);
	}
}
