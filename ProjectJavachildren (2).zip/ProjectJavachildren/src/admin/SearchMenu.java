package admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class SearchMenu {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public SearchMenu() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0 \uC870\uD68C\uD558\uAE30");
		lblNewLabel.setFont(new Font("HY����L", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(124, 13, 185, 50);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\uC2DC\uAC04\uC73C\uB85C \uC870\uD68C\uD558\uAE30");
		btnNewButton.setBackground(new Color(34, 139, 34));
		btnNewButton.setFont(new Font("HY����L", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			ClientSearchGUI gui = new ClientSearchGUI();
			frame.dispose();
			}
		});
		btnNewButton.setBounds(61, 73, 317, 44);
		frame.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("\uC774\uB984 \uBC0F \uD578\uB4DC\uD3F0 \uBC88\uD638\uB85C \uC870\uD68C\uD558\uAE30");
		button.setBackground(new Color(34, 139, 34));
		button.setFont(new Font("HY����L", Font.PLAIN, 12));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClientSearchNameGUI gui = new ClientSearchNameGUI();
				frame.dispose();
			}
		});
		button.setBounds(61, 146, 317, 44);
		frame.getContentPane().add(button);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C \uAC00\uAE30");
		btnNewButton_1.setBackground(new Color(34, 139, 34));
		btnNewButton_1.setFont(new Font("HY����L", Font.PLAIN, 12));
		btnNewButton_1.setBounds(325, 228, 97, 23);
		frame.getContentPane().add(btnNewButton_1);
	}

}
