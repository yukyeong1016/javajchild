package admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import Corona.Corona1;
import Corona.Corona15;
import Corona.Corona2;
import Corona.Corona25;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CoronaControl {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 * @param btn_corona 
	 * @param corona 
	 */
	public CoronaControl(JLabel[] corona, JButton[] btn_corona) {
		initialize(corona, btn_corona);
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 * @param btn_corona 
	 * @param corona 
	 */
	private void initialize(JLabel[] corona, JButton[] btn_corona) {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uCF54\uB85C\uB098 \uB2E8\uACC4\uBCC4 \uC88C\uC11D \uAD00\uB9AC");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(115, 30, 193, 44);
		frame.getContentPane().add(lblNewLabel);
		
		JButton button = new JButton("\uC0AC\uD68C\uC801 \uAC70\uB9AC\uB450\uAE30 1.5\uB2E8\uACC4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Corona15 corona11 = new Corona15(corona, btn_corona);
				frame.dispose();
				
			}
		});
		button.setBounds(226, 100, 178, 44);
		frame.getContentPane().add(button);
		
		JButton button_3 = new JButton("\uC0AC\uD68C\uC801 \uAC70\uB9AC\uB450\uAE30 1\uB2E8\uACC4");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Corona1 corona11 = new Corona1(corona, btn_corona);
				frame.dispose();
				
				
				
				
			}
		});
		button_3.setBounds(22, 100, 178, 44);
		frame.getContentPane().add(button_3);
		
		JButton button_1 = new JButton("\uC0AC\uD68C\uC801 \uAC70\uB9AC\uB450\uAE30 2\uB2E8\uACC4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Corona2 corona11 = new Corona2(corona, btn_corona);
				frame.dispose();
			}
		});
		button_1.setBounds(22, 173, 178, 44);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("\uC0AC\uD68C\uC801 \uAC70\uB9AC\uB450\uAE30 2.5\uB2E8\uACC4");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Corona25 corona11 = new Corona25(corona, btn_corona);
				frame.dispose();
			}
		});
		button_2.setBounds(226, 173, 178, 44);
		frame.getContentPane().add(button_2);
	}
}
