package ClientView;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import Client.ClientVO;
import Pay.PayVO;
import Seat.SeatDAO;
import Seat.SeatVO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class EnterGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 * @param vo 
	 * @param pVO 
	 */
	public EnterGUI(ClientVO vo, PayVO pVO) {
		initialize(vo, pVO);
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 * @param pVO 
	 * @param vo 
	 * @param pVO 
	 */
	private void initialize(ClientVO vo, PayVO pVO) {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBounds(100, 100, 291, 228);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("\uC785\uC2E4\uD558\uAE30");
		btnNewButton.setFont(new Font("HY����L", Font.PLAIN, 15));
		btnNewButton.setBackground(new Color(34, 139, 34));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SeatDAO sdao = new SeatDAO();
				SeatVO sVO = sdao.enter(vo, pVO);
				if (sVO!=null)
					JOptionPane.showMessageDialog(null, "�Խ��� �Ϸ�Ǿ����ϴ�.");
					FirstVIewGUI frist = new FirstVIewGUI(vo, pVO, sVO);
					frame.dispose();
			}
		});
		btnNewButton.setBounds(12, 81, 252, 89);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("\uC785\uC2E4\uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?");
		lblNewLabel.setFont(new Font("HY����L", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(41, 21, 189, 50);
		frame.getContentPane().add(lblNewLabel);
	}
}
