
public class ManagerVO {
	private String id;
	private String pw;
	private String address;

	public ManagerVO(String id, String pw, String address) {
		super();
		this.id = id;
		this.pw = pw;
		this.address = address;

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public void setName(String name) {
		this.address = address;
	}

}
