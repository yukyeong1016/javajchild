import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;

public class PassPurchaseGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */

	
	public PassPurchaseGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 400, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC774\uC6A9\uAD8C \uAD6C\uB9E4");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setFont(new Font("�޸ո���T", Font.PLAIN, 16));
		lblNewLabel.setBounds(92, 11, 88, 65);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btn_retrun = new JButton("\u2190");
		btn_retrun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BrMain.main(null);
				frame.dispose();
			}
		});
		btn_retrun.setFont(new Font("�޸ո���T", Font.PLAIN, 16));
		btn_retrun.setBounds(0, 0, 58, 41);
		frame.getContentPane().add(btn_retrun);
		
		JLabel lblNewLabel_1 = new JLabel("\uC774\uC6A9\uAD8C");
		lblNewLabel_1.setFont(new Font("�޸ո���T", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(46, 82, 78, 41);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btn_passTwo = new JButton("2\uC2DC\uAC04\uAD8C                                             ");
		btn_passTwo.setHorizontalAlignment(SwingConstants.LEFT);
		btn_passTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "�̿�� ���� �Ϸ�");
			}
		});
		btn_passTwo.setBounds(46, 133, 292, 52);
		frame.getContentPane().add(btn_passTwo);
		
		JButton btn_passFour = new JButton("4\uC2DC\uAC04\uAD8C                                            ");
		btn_passFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�̿�� ���� �Ϸ�");
			}
		});
		btn_passFour.setHorizontalAlignment(SwingConstants.LEFT);
		btn_passFour.setBounds(46, 198, 292, 52);
		frame.getContentPane().add(btn_passFour);
		
		JButton btn_passEight = new JButton("8\uC2DC\uAC04\uAD8C                                             ");
		btn_passEight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�̿�� ���� �Ϸ�");
			}
		});
		btn_passEight.setHorizontalAlignment(SwingConstants.LEFT);
		btn_passEight.setBounds(46, 264, 292, 52);
		frame.getContentPane().add(btn_passEight);
		
		JButton btn_passTw = new JButton("12\uC2DC\uAC04\uAD8C                                          ");
		btn_passTw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�̿�� ���� �Ϸ�");
			}
		});
		btn_passTw.setHorizontalAlignment(SwingConstants.LEFT);
		btn_passTw.setBounds(46, 326, 292, 52);
		frame.getContentPane().add(btn_passTw);
		
		JButton btn_passTf = new JButton("24\uC2DC\uAC04\uAD8C                                         ");
		btn_passTf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�̿�� ���� �Ϸ�");
			}
		});
		btn_passTf.setHorizontalAlignment(SwingConstants.LEFT);
		btn_passTf.setBounds(46, 388, 292, 52);
		frame.getContentPane().add(btn_passTf);
	}
}
