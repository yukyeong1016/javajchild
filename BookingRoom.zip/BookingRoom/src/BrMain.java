import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class BrMain {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BrMain window = new BrMain();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public BrMain() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btn_passPurchase = new JButton("\uC774\uC6A9\uAD8C\uAD6C\uB9E4");
		btn_passPurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PassPurchaseGUI join = new PassPurchaseGUI();
				frame.dispose();
				
				
			}
		});
		btn_passPurchase.setBounds(70, 121, 167, 88);
		frame.getContentPane().add(btn_passPurchase);
		
		JLabel lblNewLabel = new JLabel("\uBD80\uD0B9\uB8F8 SMHRD\uC810");
		lblNewLabel.setForeground(new Color(34, 139, 34));
		lblNewLabel.setFont(new Font("�޸տ�����", Font.PLAIN, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(193, 61, 189, 63);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btn_seatCurrent = new JButton("\uC88C\uC11D\uD604\uD669");
		btn_seatCurrent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		btn_seatCurrent.setBounds(70, 239, 167, 88);
		frame.getContentPane().add(btn_seatCurrent);
		
		JButton btn_seatReservation = new JButton("\uC88C\uC11D\uC608\uC57D");
		btn_seatReservation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_seatReservation.setBounds(347, 121, 167, 88);
		frame.getContentPane().add(btn_seatReservation);
		
		JButton btn_reservationC = new JButton("\uC608\uC57D\uD655\uC778");
		btn_reservationC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_reservationC.setBounds(347, 239, 167, 88);
		frame.getContentPane().add(btn_reservationC);
		
		JLabel lblNewLabel_1 = new JLabel("STUDY CAFE");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("���ʷҵ���", Font.PLAIN, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(179, 10, 216, 42);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
