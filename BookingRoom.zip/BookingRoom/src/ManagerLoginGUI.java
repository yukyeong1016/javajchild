import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ManagerLoginGUI {

	private JFrame frame;
	private JTextField tf_loginId;
	private JTextField tf_loginPw;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerLoginGUI window = new ManagerLoginGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ManagerLoginGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 400, 250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("\uAD00\uB9AC\uC790 \uB85C\uADF8\uC778");
		lblNewLabel.setFont(new Font("�޸տ�����", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(128, 27, 128, 23);
		frame.getContentPane().add(lblNewLabel);

		tf_loginId = new JTextField();
		tf_loginId.setBounds(186, 79, 133, 33);
		frame.getContentPane().add(tf_loginId);
		tf_loginId.setColumns(10);

		tf_loginPw = new JTextField();
		tf_loginPw.setColumns(10);
		tf_loginPw.setBounds(186, 122, 133, 33);
		frame.getContentPane().add(tf_loginPw);

		JButton btn_login = new JButton("\uB85C\uADF8\uC778");
		btn_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = tf_loginId.getText();
				String pw = tf_loginPw.getText();

				ManagerDAO dao = new ManagerDAO();
				ManagerVO vo = dao.loginSelect(id,pw);
				
				if (vo==null) {
					JOptionPane.showMessageDialog(null, "�α��ν���", "�α���", JOptionPane.ERROR_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, vo.getId() + "ȯ���մϴ�");
				}

			}
		});
		btn_login.setFont(new Font("�޸յձ�������", Font.PLAIN, 13));
		btn_login.setBackground(new Color(50, 205, 50));
		btn_login.setForeground(new Color(255, 255, 255));
		btn_login.setBounds(84, 165, 97, 33);
		frame.getContentPane().add(btn_login);

		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514");
		lblNewLabel_1.setFont(new Font("�޸ո���T", Font.PLAIN, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(84, 79, 67, 33);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1_1.setFont(new Font("�޸ո���T", Font.PLAIN, 14));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(84, 122, 67, 33);
		frame.getContentPane().add(lblNewLabel_1_1);

		JButton btn_dispose = new JButton("\uB2EB\uAE30");
		btn_dispose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//�������.main(null);
				frame.dispose();
			}
		});
		btn_dispose.setForeground(Color.WHITE);
		btn_dispose.setFont(new Font("�޸յձ�������", Font.PLAIN, 13));
		btn_dispose.setBackground(new Color(50, 205, 50));
		btn_dispose.setBounds(196, 165, 97, 33);
		frame.getContentPane().add(btn_dispose);
	}
}
