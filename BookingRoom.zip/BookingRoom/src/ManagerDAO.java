import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ManagerDAO {
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";

			conn = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public ManagerVO loginSelect(String id, String pw) {
		ManagerVO vo=null;
		connect();
		String sql = "select * from bookingroomadmin where adminid=? and adminpassword=?";

		try {
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);
			pst.setString(2, pw);
			rs = pst.executeQuery();

			while (rs.next()) {
				String getId = rs.getString(1);
				String getPw = rs.getString(2);
				String getAddress = rs.getString(3);
				

			 vo = new ManagerVO(getId, getPw, getAddress);
			}
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			close();
		}
		return vo;
	}
}


