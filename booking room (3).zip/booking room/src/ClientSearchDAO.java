import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;









public class ClientSearchDAO {

	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	private String url ="jdbc:oracle:thin:@localhost:1521:xe";
	private String user ="hr";
	private String password ="hr";
	
	
	
	public ArrayList<ClientSearchDTO> timeSearch() {
		ArrayList<ClientSearchDTO> list = new ArrayList<ClientSearchDTO>();
		ClientSearchGUI gui = new ClientSearchGUI();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection(url, user, password);

			String sql = "select phonenumber,password,name,address,paytime,to_number(to_char(starttime,'yyyymmddhh24miss')),to_number(to_char(endtime,'yyyymmddhh24miss')) from bookingroomclient";
			
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			
			while (rs.next()) {

				String phonenumber = rs.getString(1);
				String password = rs.getString(2);
				String name = rs.getString(3);
				String address = rs.getString(4);
				int paytime = rs.getInt(5);
				long starttime = rs.getLong(6);
				long endtime = rs.getLong(7);
				
				ClientSearchDTO dto = new ClientSearchDTO(phonenumber, password, name, address, paytime, starttime, endtime);
				list.add(dto);
				

			}
			

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pst != null)
					pst.close();
				if (conn != null)
					conn.close();
			
				
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return list;
	}
	
	





		
	}


