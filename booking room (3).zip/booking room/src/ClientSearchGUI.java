import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.handler.MessageContext.Scope;

import oracle.sql.DATE;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Panel;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
public class ClientSearchGUI {

	private JFrame frame;
	private JTextField year;
	private JTextField month;
	private JTextField day;
	private JTextField hour_1;
	private JTextField minutes_1;
	private JTable table;
	JScrollPane scrollPane;
	private JTextField hour_2;
	private JTextField minutes_2;

	
	String[] title = {"��ȭ��ȣ","�̸�","�ּ�","�ð�","���۽ð�","�����ð�"};
	Object[][] data;
	Object[][] data1;
	
	Scanner sc = new Scanner(System.in);
	private JTextField seconds_1;
	private JTextField seconds_2;
	
	private String year1;
	String month1;
	String day1;
	String hour1;
	String minutes1;
	String seconds1;
	String hour2;
	String minutes2;
	String seconds2;
	Object result;
	Object result1;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientSearchGUI window = new ClientSearchGUI();
					window.frame.setVisible(true);
					
		
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClientSearchGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 848, 556);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel clientsearch = new JLabel("\uD68C\uC6D0\uC870\uD68C");
		clientsearch.setFont(new Font("����", Font.BOLD, 22));
		clientsearch.setHorizontalAlignment(SwingConstants.CENTER);
		clientsearch.setBounds(352, 10, 92, 48);
		frame.getContentPane().add(clientsearch);
		
		JButton closebutton = new JButton("\uB2EB\uAE30");
		closebutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
			}
		});
		closebutton.setBounds(722, 479, 97, 23);
		frame.getContentPane().add(closebutton);
		
		JLabel lblNewLabel_1 = new JLabel("\uB144\uB3C4");
		lblNewLabel_1.setBounds(133, 90, 34, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uC6D4");
		lblNewLabel_2.setBounds(203, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("\uC77C");
		lblNewLabel_2_1.setBounds(261, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_3 = new JLabel("\uC2DC");
		lblNewLabel_2_3.setBounds(319, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel("\uBD84");
		lblNewLabel_2_4.setBounds(383, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_4);
		
		
		
		
		year = new JTextField();
		year.setBounds(44, 87, 83, 21);
		frame.getContentPane().add(year);
		year.setColumns(10);
		year.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
				year1 = year.getText();
				
			}
		});
		

		month = new JTextField();
		month.setColumns(10);
		month.setBounds(164, 87, 34, 21);
		frame.getContentPane().add(month);
		month.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				month1 = month.getText();
				
			}
		});
		
		day = new JTextField();
		day.setColumns(10);
		day.setBounds(224, 87, 34, 21);
		frame.getContentPane().add(day);
		day.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				day1 = day.getText();
				
			}
		});
		
		hour_1 = new JTextField();
		hour_1.setBounds(275, 87, 41, 21);
		frame.getContentPane().add(hour_1);
		hour_1.setColumns(10);
		hour_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 hour1 = hour_1.getText();
				
			}
		});
		
		minutes_1 = new JTextField();
		minutes_1.setBounds(339, 87, 41, 21);
		frame.getContentPane().add(minutes_1);
		minutes_1.setColumns(10);
		minutes_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				minutes1 = minutes_1.getText();
				
			}
		});
		
		
		
		JLabel lblNewLabel_3 = new JLabel("~");
		lblNewLabel_3.setBounds(478, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		hour_2 = new JTextField();
		hour_2.setColumns(10);
		hour_2.setBounds(504, 87, 41, 21);
		frame.getContentPane().add(hour_2);
		hour_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hour2 = hour_2.getText();
				
			}
		});
		
		JLabel lblNewLabel_2_3_1 = new JLabel("\uC2DC");
		lblNewLabel_2_3_1.setBounds(548, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_3_1);
		
		minutes_2 = new JTextField();
		minutes_2.setColumns(10);
		minutes_2.setBounds(569, 87, 41, 21);
		frame.getContentPane().add(minutes_2);
		minutes_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				minutes2 = minutes_2.getText();
				
				
			}
		});
		;
		
		frame.setVisible(true);
		
		JLabel lblNewLabel_2_4_1 = new JLabel("\uBD84");
		lblNewLabel_2_4_1.setBounds(615, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_4_1);
		
		seconds_2 = new JTextField();
		seconds_2.setColumns(10);
		seconds_2.setBounds(636, 87, 41, 21);
		frame.getContentPane().add(seconds_2);
		seconds_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				seconds2 = seconds_2.getText();
				System.out.println(year1 + month1 + day1 + hour1 + minutes1 + seconds1);
				System.out.println(year1 + month1 + day1 + hour2 + minutes2 + seconds2);
				 result = year1 + month1 + day1 + hour1 + minutes1 + seconds1;
				 result1 = year1 + month1 + day1 + hour2 + minutes2 + seconds2;
				
				
			}
		});	
		
		
		JButton searchbutton = new JButton("\uAC80\uC0C9");
		searchbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				
				ClientSearchDAO dao = new ClientSearchDAO();
				ArrayList<ClientSearchDTO> list = dao.timeSearch();
				
				data = new Object[list.size()][6];
				data1 = new Object[list.size()][6];
				
				for(int i = 0; i < list.size(); i++) {
					
						
					
					data[i][0] = list.get(i).getPhonenumber();
					data[i][1] = list.get(i).getName();
					data[i][2] = list.get(i).getAddress();
					data[i][3] = list.get(i).getPaytime();
					data[i][4] = list.get(i).getStarttime();
					data[i][5] = list.get(i).getEndtime();
					
				}
					
				
				for(int i = 0 ; i < list.size(); i++) {
					if((long)data[i][4] >= Integer.parseInt((String) result) && (long)data[i][5] <= Integer.parseUnsignedInt((String) result1)) {	
						data1[i][0] = list.get(i).getPhonenumber();
						data1[i][1] = list.get(i).getName();
						data1[i][2] = list.get(i).getAddress();
						data1[i][3] = list.get(i).getPaytime();
						data1[i][4] = list.get(i).getStarttime();
						data1[i][5] = list.get(i).getEndtime();
					}
				}
				table = new JTable(data1, title);
				scrollPane = new JScrollPane(table);
				scrollPane.setBounds(45, 131, 730, 280);
				scrollPane.setVisible(true);
				frame.getContentPane().add(scrollPane);
				
				
			}
		});
		searchbutton.setBounds(709, 86, 66, 23);
		frame.getContentPane().add(searchbutton);
		
		seconds_1 = new JTextField();
		seconds_1.setColumns(10);
		seconds_1.setBounds(413, 87, 41, 21);
		frame.getContentPane().add(seconds_1);
		seconds_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 seconds1 = seconds_1.getText();
				
			}
		}); 
		
		
		
		JLabel lblNewLabel_2_5 = new JLabel("\uCD08");
		lblNewLabel_2_5.setBounds(458, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_5);
		
		
		
		JLabel lblNewLabel_2_4_2 = new JLabel("\uCD08");
		lblNewLabel_2_4_2.setBounds(681, 90, 20, 15);
		frame.getContentPane().add(lblNewLabel_2_4_2);
		
		JButton namesearch = new JButton("\uC774\uB984");
		namesearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NameSearchGUI.main(null);
				frame.dispose();
			}
		});
		namesearch.setBounds(30, 43, 71, 23);
		frame.getContentPane().add(namesearch);
		
		JButton timesearch = new JButton("\uC2DC\uAC04");
		timesearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClientSearchGUI.main(null);
				frame.dispose();
			}
		});
		timesearch.setBounds(101, 43, 66, 23);
		frame.getContentPane().add(timesearch);
		
		JButton seatsearch = new JButton("\uC88C\uC11D");
		seatsearch.setBounds(164, 43, 66, 23);
		frame.getContentPane().add(seatsearch);
		
		
	}
	}

